import boto3


S3 = boto3.resource(
    's3',
    region_name='us-west-2',
    aws_access_key_id="AKIAF06E7MXBSH9DHM02",
    aws_secret_access_key="kWcrlUX5JEDGM/LtmEENI/aVmYvHNif5zB+d9+ct"
)

S3.Object( "random_bucket", "random_key" ).delete()