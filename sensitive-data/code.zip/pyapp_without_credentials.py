import boto3


some_random_data = "AKIAF06E7MXBSH9DHM02"
some_other_random_data = "kWcrlUX5JEDGM/LtmEENI/aVmYvHNif5zB+d9+ct"

S3 = boto3.resource(
    's3',
    region_name='us-west-2',
    aws_access_key_id=some_random_data,
    aws_secret_access_key=some_other_random_data
)

S3.Object( "random_bucket", "random_key" ).delete()